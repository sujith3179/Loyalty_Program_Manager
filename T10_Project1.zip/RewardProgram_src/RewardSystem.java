//A class that holds variables affected by all functions.
import java.sql.*;
public class RewardSystem
{
	public static String systemState;
	public static String userID;
	public static String userType;
	public static Connection conn;
	public static String loyaltyProgramID;
}